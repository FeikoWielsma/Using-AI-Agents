# Launch readiness workspace

## Start here
Read [BRIEF.md](BRIEF.md), [MEMORY.md](MEMORY.md) and [PROCEDURE.md](PROCEDURE.md) when present. Then inspect the source pack.

## Source records
The `sources/` folder is read-only evidence. Start at [case overview](sources/case-overview.md).

## Working documents
Ask the agent to propose BRIEF.md, MEMORY.md, PROCEDURE.md and DECISIONS.md. Review each proposed update before applying it. File names are this workspace's conventions.

## Resuming
A fresh conversation has no earlier chat history. Explicitly ask it to read this workspace. Download a ZIP before leaving Colab; runtime files are temporary.
