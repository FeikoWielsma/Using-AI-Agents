# Review checklist version 2

Document: CA-204/review-checklist-v2.md
Date: 2026-08-28
Owner: Elena Vos
Organisation: Aster Service Systems
Status: fictional training record

Status: approved, current. Supersedes version 1.
## Gate G-01
The approved internal checklist requires 30 consecutive conforming records after training, with independent review, before closure may be proposed.
## Other review requirements
30 consecutive conforming records; investigated exceptions; independent reviewer; quality-owner decision.
Each completion statement needs a dated source, the relevant record or run ID,
and an owner. Forecasts and assumptions must be labelled. Missing evidence is
recorded as unknown, not silently inferred from a green dashboard.
## Authority
The responsible review owner makes the decision. An analyst may prepare a
recommendation, questions and a draft communication. Preparation is not approval.
External communication requires the named owner's review of the exact text.
