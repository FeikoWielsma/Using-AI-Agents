# Scope and working definitions

Document: CA-204/scope-and-definitions.md
Date: 2026-08-28
Owner: Elena Vos
Organisation: Aster Service Systems
Status: fictional training record

Project: CA-204. Subject: service-record corrective action.
Evidence means a dated result or record that supports the particular claim.
Implemented means an action has been performed; accepted means the designated
owner has reviewed its result. Those states are recorded separately.
Forecast is the current estimate; baseline is the authorised plan.
Unknown means the supplied records do not establish a fact.
## Case-specific requirement
The approved internal checklist requires 30 consecutive conforming records after training, with independent review, before closure may be proposed.
## Exclusions
No access to production systems, customer accounts or external communications.
The documents do not supply facts about systems outside this fictional pack.
