# Stakeholders and responsibilities

Document: CA-204/stakeholder-map.md
Date: 2026-09-01
Owner: Elena Vos
Organisation: Aster Service Systems
Status: fictional training record

| Role | Person | Responsibility |
| --- | --- | --- |
| Review owner | Elena Vos | Present evidence and seek the accountable decision |
| Sponsor | Theo Smit | Resolve scope and resource trade-offs |
| Evidence lead | Amir de Jong | Maintain E-series evidence records |
| Communications lead | Lotte Visser | Prepare communications for owner approval |
| Independent reviewer | Robin Bos | Challenge completion claims against the current checklist |

The agent may propose follow-up questions to these roles. This directory does
not authorise sending messages or record that any of these people agreed.
