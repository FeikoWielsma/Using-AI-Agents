# Change request CR-17

Document: PR-417/change-request-17.md
Date: 2026-09-07
Owner: Nora Bakker
Organisation: Westhaven Networks
Status: fictional training record

Requested change: replan the migration wave after the Access workstream forecast
moved to 22 September. Field forecasts 23 September and depends on Access.
Status: pending board review. No effective revised baseline is recorded.
Options: keep the baseline with explicit scope reduction, or approve a revised
wave date after dependency confirmation. Each option needs an impact assessment.
The board meets on 11 September. An accepted workstream dependency is not the
board's approval of the programme change.
