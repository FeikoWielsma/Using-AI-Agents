# Review checklist version 2

Document: PR-417/review-checklist-v2.md
Date: 2026-08-28
Owner: Nora Bakker
Organisation: Westhaven Networks
Status: fictional training record

Status: approved, current. Supersedes version 1.
## Gate G-01
The baseline approved on 28 August is 18 September. A new forecast does not change the baseline without a recorded board decision.
## Other review requirements
Accepted dependency dates; resource coverage; change decision; test evidence; accountable workstream owners.
Each completion statement needs a dated source, the relevant record or run ID,
and an owner. Forecasts and assumptions must be labelled. Missing evidence is
recorded as unknown, not silently inferred from a green dashboard.
## Authority
The responsible review owner makes the decision. An analyst may prepare a
recommendation, questions and a draft communication. Preparation is not approval.
External communication requires the named owner's review of the exact text.
