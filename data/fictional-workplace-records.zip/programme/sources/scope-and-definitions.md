# Scope and working definitions

Document: PR-417/scope-and-definitions.md
Date: 2026-08-28
Owner: Nora Bakker
Organisation: Westhaven Networks
Status: fictional training record

Project: PR-417. Subject: network migration wave.
Evidence means a dated result or record that supports the particular claim.
Implemented means an action has been performed; accepted means the designated
owner has reviewed its result. Those states are recorded separately.
Forecast is the current estimate; baseline is the authorised plan.
Unknown means the supplied records do not establish a fact.
## Case-specific requirement
The baseline approved on 28 August is 18 September. A new forecast does not change the baseline without a recorded board decision.
## Exclusions
No access to production systems, customer accounts or external communications.
The documents do not supply facts about systems outside this fictional pack.
