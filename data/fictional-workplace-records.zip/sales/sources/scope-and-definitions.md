# Scope and working definitions

Document: AC-318/scope-and-definitions.md
Date: 2026-08-28
Owner: Jonas Meijer
Organisation: Riverton Connectivity
Status: fictional training record

Project: AC-318. Subject: managed connectivity proposal.
Evidence means a dated result or record that supports the particular claim.
Implemented means an action has been performed; accepted means the designated
owner has reviewed its result. Those states are recorded separately.
Forecast is the current estimate; baseline is the authorised plan.
Unknown means the supplied records do not establish a fact.
## Case-specific requirement
Product sheet v3 promises a four-hour response during business hours. It does not promise four-hour restoration or round-the-clock support.
## Exclusions
No access to production systems, customer accounts or external communications.
The documents do not supply facts about systems outside this fictional pack.
