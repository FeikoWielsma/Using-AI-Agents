# Budget and effort note

Document: AC-318/budget-note.md
Date: 2026-09-02
Owner: Jonas Meijer
Organisation: Riverton Connectivity
Status: fictional training record

Approved review allocation: 40 hours at an illustrative internal rate of EUR 90.
Recorded effort to date: 26 hours. Remaining allocation: 14 hours, EUR 1,260.
These figures cover review effort only, not programme delivery or supplier spend.
An additional two-day review at eight hours per day would exceed the remaining
allocation by two hours. The sponsor must approve any increase.
No agent licence price or API tariff is inferred from this internal rate.
