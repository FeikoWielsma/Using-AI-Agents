# Managed service product sheet v3

Document: AC-318/product-sheet-v3.md
Date: 2026-08-28
Owner: Jonas Meijer
Organisation: Riverton Connectivity
Status: fictional training record

Business-hours service: Monday-Friday 08:00-18:00, excluding public holidays.
Support response target: four hours within that window. Restoration time depends
on diagnosis, third-party access and fault type; no four-hour restoration promise
is included. Round-the-clock service is a separately reviewed option.
Cedar Retail has requested 20 branches. Sites CED-19 and CED-20 need surveys.
Indicative monthly fee: EUR 180 per branch, subject to validated scope. Twenty
branches would total EUR 3,600 per month; this is not an approved offer.
