# Review checklist version 2

Document: AC-318/review-checklist-v2.md
Date: 2026-08-28
Owner: Jonas Meijer
Organisation: Riverton Connectivity
Status: fictional training record

Status: approved, current. Supersedes version 1.
## Gate G-01
Product sheet v3 promises a four-hour response during business hours. It does not promise four-hour restoration or round-the-clock support.
## Other review requirements
Confirmed site scope; validated coverage; supported SLA wording; delivery approval; commercial owner.
Each completion statement needs a dated source, the relevant record or run ID,
and an owner. Forecasts and assumptions must be labelled. Missing evidence is
recorded as unknown, not silently inferred from a green dashboard.
## Authority
The responsible review owner makes the decision. An analyst may prepare a
recommendation, questions and a draft communication. Preparation is not approval.
External communication requires the named owner's review of the exact text.
