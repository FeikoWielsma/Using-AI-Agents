# Scope and working definitions

Document: REL-62/scope-and-definitions.md
Date: 2026-08-28
Owner: Samira de Wit
Organisation: Juniper Digital Bank
Status: fictional training record

Project: REL-62. Subject: mobile payment-confirmation change.
Evidence means a dated result or record that supports the particular claim.
Implemented means an action has been performed; accepted means the designated
owner has reviewed its result. Those states are recorded separately.
Forecast is the current estimate; baseline is the authorised plan.
Unknown means the supplied records do not establish a fact.
## Case-specific requirement
AC-07 requires interruption and reconnect coverage on both iOS and Android. A passed happy-path test does not cover reconnect behaviour.
## Exclusions
No access to production systems, customer accounts or external communications.
The documents do not supply facts about systems outside this fictional pack.
