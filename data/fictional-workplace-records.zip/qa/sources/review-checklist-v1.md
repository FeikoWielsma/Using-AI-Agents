# Review checklist version 1

Document: REL-62/review-checklist-v1.md
Date: 2026-08-03
Owner: Samira de Wit
Organisation: Juniper Digital Bank
Status: fictional training record

Status: superseded by review-checklist-v2.md, effective 28 August.
The initial pilot allowed a workstream owner's written completion statement.
The pilot checklist did not require a linked independent evidence record for
every gate. This version is retained to explain earlier dashboard conventions.
It must not determine the current review outcome.
