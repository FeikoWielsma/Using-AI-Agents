# Review checklist version 2

Document: REL-62/review-checklist-v2.md
Date: 2026-08-28
Owner: Samira de Wit
Organisation: Juniper Digital Bank
Status: fictional training record

Status: approved, current. Supersedes version 1.
## Gate G-01
AC-07 requires interruption and reconnect coverage on both iOS and Android. A passed happy-path test does not cover reconnect behaviour.
## Other review requirements
Acceptance-criterion coverage; both mobile platforms; linked test evidence; defect disposition; release-owner decision.
Each completion statement needs a dated source, the relevant record or run ID,
and an owner. Forecasts and assumptions must be labelled. Missing evidence is
recorded as unknown, not silently inferred from a green dashboard.
## Authority
The responsible review owner makes the decision. An analyst may prepare a
recommendation, questions and a draft communication. Preparation is not approval.
External communication requires the named owner's review of the exact text.
