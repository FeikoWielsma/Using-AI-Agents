# Payment confirmation acceptance criteria

Document: REL-62/acceptance-criteria.md
Date: 2026-08-28
Owner: Samira de Wit
Organisation: Juniper Digital Bank
Status: fictional training record

AC-01: show amount and payee before confirmation.
AC-02: cancellation leaves no submitted payment.
AC-03: invalid amount produces a clear message.
AC-04: successful confirmation shows a reference.
AC-05: repeated taps must not create duplicate submissions.
AC-06: confirmation text is readable with the supported accessibility settings.
AC-07: interruption and reconnect must not duplicate or lose the submission;
test this on both supported mobile platforms. TC-007 and TC-008 cover AC-07.
D-44 blocks the iOS reconnect path. The summary all criteria passed is not
supported by these results. The training data does not describe a live bank app.
